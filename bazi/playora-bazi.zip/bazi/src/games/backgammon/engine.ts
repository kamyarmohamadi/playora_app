export type Player='white'|'black'; export type Board=number[]; export type Dice=[number,number];
export const initialBoard=():Board=>{const b=Array(24).fill(0);b[0]=2;b[11]=5;b[16]=3;b[18]=5;b[23]=-2;b[12]=-5;b[7]=-3;b[5]=-5;return b};
export function legalDestinations(board:Board,from:number,player:Player,dice:number[]):number[]{const dir=player==='white'?1:-1;return dice.map(d=>from+dir*d).filter(to=>to>=0&&to<24&& (board[to]* (player==='white'?1:-1))>-2)}
export function applyMove(board:Board,from:number,to:number,player:Player){const sign=player==='white'?1:-1;if(board[from]*sign<=0)throw Error('مهرهٔ بازیکن شما نیست');if(board[to]*sign<-1)throw Error('خانه بسته است');if(board[to]*sign===-1)board[to]=sign;else board[to]+=sign;board[from]-=sign;return board}
export function rollDice(rng=Math.random):Dice{ return [Math.floor(rng()*6)+1,Math.floor(rng()*6)+1] as Dice }
