import type {GameManifest} from './types';
const semver=/^\\d+\\.\\d+\\.\\d+$/;
export function validateManifest(m:unknown,api='1.0.0'):m is GameManifest { if(!m||typeof m!=='object')return false; const x=m as Partial<GameManifest>; return [x.id,x.name,x.version,x.apiVersion,x.description,x.entry].every(v=>typeof v==='string'&&v.length>0)&&semver.test(x.version!)&&x.apiVersion===api&&Array.isArray(x.permissions)&&x.permissions.every(p=>typeof p==='string'); }
