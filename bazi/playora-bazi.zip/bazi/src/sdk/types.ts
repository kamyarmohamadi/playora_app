export type GameStatus='ready'|'running'|'paused'|'finished'|'error';
export type GameManifest={id:string;name:string;version:string;apiVersion:string;description:string;entry:string;permissions:string[]};
export type GameContext={emit:(event:string,payload:unknown)=>void; log:(message:string)=>void};
export type GameModule={manifest:GameManifest; mount:(root:HTMLElement,ctx:GameContext)=>void; unmount:()=>void; pause?:()=>void; resume?:()=>void};
