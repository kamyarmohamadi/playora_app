# Playora
This is a sample Android project structure for Playora.